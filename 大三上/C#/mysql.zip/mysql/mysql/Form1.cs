﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;

namespace mysql
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private MySqlConnection GetMysqlConnection()
        {
            string str = "Server=127.0.0.1;User ID=root;Password=root;Database=C#test;CharSet=utf8;";
            return new MySqlConnection(str);
        }

        private void Close(MySqlConnection m)
        {
            if (m.State==ConnectionState.Open)
            {
                m.Close();
            }
        }
        //显示所有数据
        private void Show()
        {
            //获取mysql连接
            MySqlConnection con = GetMysqlConnection();
            //开启连接
            con.Open();
            string Select = string.Format(@"SELECT * from Book");
            //创建MySqlCommand对象
            MySqlCommand cmd = new MySqlCommand(Select, con);

            MySqlDataAdapter ada = new MySqlDataAdapter(cmd);

            DataSet ds = new DataSet();
            //查询结果填充数据集
            ada.Fill(ds, "table");

            dataGridView1.DataSource = ds.Tables["table"];
            //关闭连接
            Close(con);
        }
        
        //刷新
        private void button1_Click(object sender, EventArgs e)
        {
            Show();
        }
        
        //判断是否为价格
        bool IfPrice(string str)
        {
            string pattern = @"([0-9])*(\.?([0-9]))*";
            string temp = null;
            foreach (Match match in Regex.Matches(str, pattern))
                temp += match.Value;
            label5.Text = temp;
            if (temp == str)
                return true;
            return false;
        }
        
        //信息校验
        private bool Validate()
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                label5.ForeColor = Color.Red;
                label5.Text = "书的信息必须完整";
                return false;
            }
            if (!IfPrice(textBox4.Text))
            {
                label5.ForeColor = Color.Red;
                label5.Text = "价格必须是一串数字";
                return false;
            }
            return true;
        }

        //添加数据
        private void button2_Click(object sender, EventArgs e)
        {
            if (!Validate())
            {
                return;
            }
            //获取mysql连接
            MySqlConnection con = GetMysqlConnection();
            //开启连接
            con.Open();
            string Add = string.Format(@"insert into Book(Name,Author,Press,Price) values(@Name,@Author,@Press,@Price)");
            //创建MySqlCommand对象
            MySqlCommand cmd = new MySqlCommand(Add, con);
            cmd.Parameters.AddWithValue("@Name",textBox1.Text);
            cmd.Parameters.AddWithValue("@Author", textBox2.Text);
            cmd.Parameters.AddWithValue("@Press", textBox3.Text);
            cmd.Parameters.AddWithValue("@Price", label5.Text );
            if (cmd.ExecuteNonQuery() == 1)
            {
                label5.ForeColor = Color.Green;
                label5.Text = "添加成功！";
            }
            else
            {
                label5.ForeColor = Color.Red;
                label5.Text = "添加失败！";
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            //关闭连接
            Close(con);
        }
       
        //修改数据
        private void button3_Click(object sender, EventArgs e)
        {
            if (!Validate())
            {
                return;
            }
            //获取当前选中的书的ID
            int ID=int.Parse(dataGridView1.CurrentRow.Cells["ID"].Value.ToString());
            //获取mysql连接
            MySqlConnection con = GetMysqlConnection();
            //开启连接
            con.Open();
            string Update = string.Format(@"update Book set Name=@Name,Author=@Author,Press=@Press,Price=@Price where ID=@ID");
            //创建MySqlCommand对象
            MySqlCommand cmd = new MySqlCommand(Update, con);
            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
            cmd.Parameters.AddWithValue("@Author", textBox2.Text);
            cmd.Parameters.AddWithValue("@Press", textBox3.Text);
            cmd.Parameters.AddWithValue("@Price", double.Parse(label5.Text));
            cmd.Parameters.AddWithValue("@ID", ID);
            if (cmd.ExecuteNonQuery() == 1)
            {
                label5.ForeColor = Color.Green;
                label5.Text = "修改成功！";
            }
            else
            {
                label5.ForeColor = Color.Red;
                label5.Text = "修改失败！";
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            //关闭连接
            Close(con);
        }

        //运行加载
        private void Form1_Load(object sender, EventArgs e)
        {
            //第一次进入加载数据
            Show();
        }

        //点击空白处
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            label5.Text = "";
        }

        //将选中的行数据显示到textBox框
        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells["Name"].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells["Author"].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells["Press"].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells["Price"].Value.ToString();
        }

        //删除数据
        private void button5_Click(object sender, EventArgs e)
        { 
            //获取当前选中的书的ID
            int ID = int.Parse(dataGridView1.CurrentRow.Cells["ID"].Value.ToString());
            //获取mysql连接
            MySqlConnection con = GetMysqlConnection();
            //开启连接
            con.Open();
            string Update = string.Format(@"delete from Book where ID=@ID");
            //创建MySqlCommand对象
            MySqlCommand cmd = new MySqlCommand(Update, con);
            cmd.Parameters.AddWithValue("@ID", ID);
            if (cmd.ExecuteNonQuery() == 1)
            {
                label5.ForeColor = Color.Green;
                label5.Text = "删除成功！";
            }
            else
            {
                label5.ForeColor = Color.Red;
                label5.Text = "删除失败！";
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            //关闭连接
            Close(con);
        }
    }
}
