﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab1_3_
{
    class Program
    {

        static void SortArray(int[] myArray, bool flag)
        {
            if (flag)
            {
                int i, j, temp;
                for (i = 0; i < myArray.Length - 1; i++)
                {
                    for (j = i + 1; j < myArray.Length; j++)
                    {
                        if (myArray[i] > myArray[j])//第一个数大于第二个数 从小到大排序
                        {
                            temp = myArray[i];
                            myArray[i] = myArray[j];
                            myArray[j] = temp;
                        }
                    }
                }
            }
            else
            {
                int i, j, temp;
                for (i = 0; i < myArray.Length - 1; i++)
                {
                    for (j = i + 1; j < myArray.Length; j++)
                    {
                        if (myArray[i] < myArray[j])//从大到小排
                        {
                            temp = myArray[i];
                            myArray[i] = myArray[j];
                            myArray[j] = temp;
                        }
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            int[] arr = new int[] {21,32,13,42,54,65,43 };
            bool flag = false;
            Console.Write("原始数组：");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
            SortArray(arr, flag);
            Console.Write("排序数组：");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
